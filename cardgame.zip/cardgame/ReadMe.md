# CARDGAME

## Before you start
1. npm install
- (Dependencies are checked in two separate folders, pack-lock and src，so npm install both)
- -------
2. node  ./app.js
- (% cd package-lock)
```
... package-lock % node  ./app.js 
body-parser deprecated undefined extended: provide extended option app.js:20:17
Server is running at http://localhost:9000
```
- ---------
3. npm start
- (% cd src)
```html
... cardgame % cd src
... src % npm start
```
- http://localhost:3000
5. Right click on the browser page to open the Inspect sidebar and turn on mode




